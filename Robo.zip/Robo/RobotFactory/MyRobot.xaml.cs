﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RobotFactory
{
    /// <summary>
    /// Interaction logic for MyRobot.xaml
    /// </summary>
    public partial class MyRobot : Page
    {
        Robot Hambo;
        private BrushConverter convert = new BrushConverter();
        public MyRobot(Robot bot)
        {
            InitializeComponent();
            Hambo = bot;
            LoadBot();
        }

        private void LoadBot()
        {
            botName.Text = $"Hello, my name is {Hambo.Name}!";

            // TODO: Add Colors
            SolidColorBrush bodyColor = convert.ConvertFromString(Hambo.BodyColor) as SolidColorBrush;
            SolidColorBrush eyeColor = convert.ConvertFromString(Hambo.EyeColor) as SolidColorBrush;
            SolidColorBrush antennaColor = convert.ConvertFromString(Hambo.AntennaColor) as SolidColorBrush;

            bdy_1.Fill = bodyColor;
            bdy_2.Fill = bodyColor;
            bdy_3.Fill = bodyColor;
            bdy_4.Fill = bodyColor;
            bdy_5.Fill = bodyColor;
            bdy_6.Fill = bodyColor;
            eye_1.Fill = eyeColor;
            eye_2.Fill = eyeColor;
            ant_1.Fill = antennaColor;
            ant_2.Fill = antennaColor;


        }


    }
}
