﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RobotFactory
{
    /// <summary>
    /// Interaction logic for Factory.xaml
    /// </summary>
    public partial class Factory : Page
    {
        Robot Hambo = new Robot();
        public Factory()
        {
            InitializeComponent();
        }

        private void PlayerName_TextChanged(object sender, TextChangedEventArgs e)
        {
            Hambo.Name = PlayerName.Text;
        }

        private void GetBodyColor(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;

            switch(button.Content.ToString())
            {
                case "Blue":
                    Hambo.BodyColor = "Blue";
                    break;
                case "Green":
                    Hambo.BodyColor = "Green";
                    break;
            }
        }

        private void GetEyeColor(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;

            switch (button.Content.ToString())
            {
                case "DarkViolet":
                    Hambo.EyeColor = "DarkViolet";
                    break;
                case "Brown":
                    Hambo.EyeColor = "Brown";
                    break;
            }
        }

        private void GetAntennaColor(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;

            switch (button.Content.ToString())
            {
                case "Yellow":
                    Hambo.AntennaColor = "Yellow";
                    break;
                case "Red":
                    Hambo.AntennaColor = "Red";
                    break;
            }
        }

        private void Back_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.GoBack();
        }

        private void BuildBot_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new MyRobot(Hambo));
        }
    }
}
