﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotFactory
{
    public class Robot
    {
        public string Name;
        public string EyeColor = "Blue";
        public string BodyColor = "Blue";
        public string AntennaColor = "Black";

        public Robot()
        {
            
        }

    }
}
